# LOD-EPSH-ENSO 项目中间产物 (intermediates)

本目录是与 Claude 协作分析 LOD-EPSH-ENSO 框架时产生的计算中间产物。
重新开始对话时，把这些文件上传到 GitHub 仓库的普通文件区，
新对话里 Claude 可通过 raw 链接拉取，快速重建分析环境，
无需从头重算（但原始 .nc/.txt 数据仍需另外提供）。

## intermediates/ 文件说明

核心:
- b2_2026.pkl              LOD 0.5-1年波段 (1963-01..2026-04)，最核心
- aam_wind.csv             风项全球AAM月度值 (1948-2026, GitHub Actions从NCEP算)
- aam_wind_anom.csv        风项AAM去季节距平
- aam_wind_band.pkl        风项AAM的0.5-1年波段
- torque_bands.pkl         全球山脉/摩擦/总力矩的0.5-1年波段
- regional_torque_bands.pkl 区域(EPSH窄/宽带)摩擦力矩波段
- band_objs.pkl            安第斯/全球山脉力矩+AAM+LOD的波段对象(画图用)
- ncep_torques_monthly.csv 力矩月度序列 (1948-01..2026-02, 5列)
- ncep_torques_0p5_1yr_band.csv 力矩0.5-1年波段CSV

滑动窗口敏感性分析波段(整数月):
- mb_5_11.pkl, mb_6_12.pkl, mb_7_13.pkl, mb_8_14.pkl, mb_9_15.pkl, mb_10_16.pkl

## scripts/ 文件说明
- compute_torques.py                  从NCEP算山脉/摩擦力矩(全球+区域)
- torque_computation_README.md        力矩计算说明
- github_actions_download_noaa.yml    GitHub Actions下载NOAA数据的workflow

## 还需要另外提供的原始数据(不在本包,体积大或你本地已有):
- pres_mon_mean.nc (25MB), uflx_mon_mean.nc (52MB), hgt_sfc.nc (小)
- uwnd.mon.mean.nc (416MB, 走Release或重新上传)
- EOP_...LOD文本, slp20-30n/s..., u2_5..., nino3stop.txt
