# Computing Mountain and Friction Torque from NCEP/NCAR Reanalysis

This note accompanies `compute_torques.py`. It explains which fields to download,
the formulas used, the validation performed, and the caveats that matter for
comparing the torques with your LOD and EPSH series.

## 1. Fields to download (NOAA PSL, anonymous FTP `ftp.cdc.noaa.gov`)

All are NCEP/NCAR Reanalysis 1, 2.5 x 2.5 degree global grid (144 x 73),
monthly means, 1948 to early 2026. Note: Reanalysis 1 stopped production with a
last date of 17 March 2026, so the series ends there.

| Purpose | File | Variable | Units | Directory |
|---|---|---|---|---|
| Mountain torque | `pres.sfc.mon.mean.nc` | pres | Pa | /Datasets/ncep.reanalysis.derived/surface/ |
| Mountain torque | `hgt.sfc.nc` | hgt | gpm (time-invariant) | /Datasets/ncep.reanalysis.derived/surface/ |
| Friction torque | `uflx.sfc.mon.mean.nc` | uflx | N/m^2 | /Datasets/ncep.reanalysis.derived/surface_gauss/ |

`uflx` (zonal surface momentum flux = zonal wind stress) lives on a Gaussian
grid, which is why it has a different latitude count than pres/hgt. That is fine:
the two torques are computed on their own native grids and joined on the time axis.

Missing value flag in all files: -9.96921e+36.

## 2. Formulas (global axial component, about Earth's rotation axis)

Mountain torque, the pressure torque exerted by topography on the atmosphere:

    T_M = -a^2 * integral integral  p_s * (dh/dlambda) * cos(phi)  dlambda dphi

where p_s is surface pressure, h is topographic height (m), lambda longitude,
phi latitude, a Earth radius. Physically, high pressure on the west face of a
mountain and low pressure on the east face produces a torque on the solid Earth.

Friction torque, the torque exerted by surface wind stress:

    T_F = a^3 * integral integral  tau_lambda * cos^2(phi)  dlambda dphi

where tau_lambda is the zonal surface stress (the downloaded uflx). The factor
a cos(phi) is the lever arm and a^2 cos(phi) dlambda dphi is the spherical area
element, which combine to a^3 cos^2(phi).

Both are divided by 1e18 to report Hadleys (1 Hadley = 1e18 kg m^2 s^-2), the
standard unit in the AAM literature, so your numbers are directly comparable to
Wahr & Oort (1984), Gong et al. (2019), and others.

## 3. Validation performed

The script was run end-to-end on synthetic NCEP-shaped files (idealized Andes and
Himalaya topography, a moving zonal pressure wave, and trade-wind-like stress).
Two things were confirmed:

- Dimensional correctness: an early version was missing one factor of Earth
  radius in each torque (mountain needs a^2, friction needs a^3). After
  correction the magnitudes land in the few-to-tens-of-Hadleys range that the
  literature reports, rather than being off by a factor of 6.4e6.
- The mountain torque oscillates in sign as the pressure wave moves across the
  topography, as expected; the friction torque tracks the imposed stress field.

The synthetic friction value was large only because the test stress field was
deliberately exaggerated; with the real uflx it falls to a realistic amplitude.

## 4. Caveats that matter for your work

Sign convention (now applied). NCEP uflx is the momentum flux from the
atmosphere to the surface. Because EPSH is an atmospheric phenomenon and you want
the torque the solid Earth exerts ON the atmosphere (the quantity that changes
atmospheric angular momentum), the script multiplies the friction torque by -1
(FRICTION_SIGN = -1.0). Verification: the tropical easterly trades remove westerly
momentum from the atmosphere, so the tropical friction torque should come out
NEGATIVE with the real data; check that before trusting the trend. The mountain
torque already follows the on-the-atmosphere convention of Wahr & Oort.

Total torque and gravity-wave torque. The full AAM budget is
T_total = T_M + T_F + T_G, where T_G is the parameterized gravity-wave-drag
torque. T_G is model-internal and not in the standard surface files, so a budget
built from only T_M and T_F will not perfectly close against observed dLOD/dt;
the literature reports a residual of order 10 Hadleys attributable mainly to
T_G. For correlating torque variability with your LOD band this is usually not a
problem, but it matters if you try to close the budget exactly.

hgt vs geopotential. The hgt.sfc field is in geopotential metres (gpm), which are
numerically almost identical to metres, so no division by g is applied. If you
instead use a surface geopotential field (phi.sfc, units m^2/s^2), divide by g.

Resolution and the high-frequency LOD band. These are monthly means, adequate for
the sub-annual to interannual variability you study. If you later want the higher
frequency torque variability that drives the 0.3 to 0.5 year LOD band, recompute
from daily uflx and pres (same directories, daily averages) rather than monthly.

## 4b. Global vs regional torque (now both)

The full global torque is the right quantity to compare with Earth rotation / LOD,
because only the global total changes the planet's spin. But since EPSH is a
regional system, the script ALSO integrates over a region (default 30 S to 30 N,
210 to 240 E, the eastern-Pacific subtropical-high belts) and reports it in the
*_region columns. The regional torque is closer in meaning to the momentum budget
of the EPSH itself and may correlate more directly with your SLP_R2 / SLP_R5
indices. Edit the REGION dict at the top of the script to match exactly the box
you use for EPSH (for one hemisphere set lat 20 to 30 or -30 to -20). Set
REGION = None to skip it.

## 5. Output

Running `python compute_torques.py` writes `ncep_torques_monthly.csv` with a
monthly DatetimeIndex and five columns: T_mountain_global, T_mountain_region,
T_friction_global, T_friction_region, and T_total_global (all in Hadleys),
ready to align with your IERS LOD and EPSH series. To compare with the 0.5 to 1
year LOD band, apply the same last-day-of-month sampling logic to align dates,
then band-pass the torque series with the identical Butterworth design you use
for LOD.
