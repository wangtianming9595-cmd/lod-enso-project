#!/usr/bin/env python3
"""
compute_torques.py
------------------
Compute axial MOUNTAIN torque and FRICTION torque from NCEP/NCAR Reanalysis 1
monthly-mean fields, following Wahr & Oort (1984).

Outputs a monthly time series (1948 to early 2026) of the torque ON THE ATMOSPHERE
(i.e. what changes atmospheric angular momentum), in Hadleys
(1 Hadley = 1e18 kg m^2 s^-2), for BOTH:
    - the whole globe
    - a user-defined region (default: the EPSH belts, 20-30 N/S, 210-240 E)
so they can be aligned directly with your LOD / EPSH series.

INPUT FILES (download from NOAA PSL, anonymous FTP ftp.cdc.noaa.gov):
  /Datasets/ncep.reanalysis.derived/surface/pres.sfc.mon.mean.nc        (pres,  Pa)
  /Datasets/ncep.reanalysis.derived/surface/hgt.sfc.nc                  (hgt,   gpm, time-invariant)
  /Datasets/ncep.reanalysis.derived/surface_gauss/uflx.sfc.mon.mean.nc  (uflx,  N/m^2, Gaussian grid)

Run:
    pip install numpy xarray netcdf4 pandas
    python compute_torques.py
"""

import numpy as np
import xarray as xr
import pandas as pd

# ----------------------------------------------------------------------
# constants & paths
# ----------------------------------------------------------------------
A      = 6.371e6          # Earth radius (m)
DEG    = np.pi/180.0
HADLEY = 1.0e18

PRES_FILE = "pres.sfc.mon.mean.nc"
HGT_FILE  = "hgt.sfc.nc"
UFLX_FILE = "uflx.sfc.mon.mean.nc"

# Friction-torque sign: NCEP uflx is the flux FROM atmosphere TO surface.
# We want the torque ON THE ATMOSPHERE (drives AAM, comparable to mountain torque),
# so flip the sign. Check: tropical easterly trades should give NEGATIVE friction torque.
FRICTION_SIGN = -1.0

# Region of interest for the regional torque (deg). Default = EPSH belts.
# Longitudes in 0-360. Set REGION = None to skip the regional output.
REGION = dict(lat_min=-30, lat_max=30, lon_min=210, lon_max=240)
# (this spans both the NH and SH subtropical-high belts over the eastern Pacific;
#  narrow it to 20-30N or 20-30S if you want one hemisphere only)

# ----------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------
def region_mask(lat_deg, lon_deg, region):
    """Boolean (lat,lon) mask for the region; lon handled in 0-360."""
    if region is None:
        return None
    la = lat_deg[:, None]; lo = lon_deg[None, :]
    m_lat = (la >= region["lat_min"]) & (la <= region["lat_max"])
    m_lon = (lo >= region["lon_min"]) & (lo <= region["lon_max"])
    return m_lat & m_lon

# ----------------------------------------------------------------------
# MOUNTAIN TORQUE   T_M = -a^2 * int int p_s (dh/dlambda) cos(phi) dlambda dphi
# ----------------------------------------------------------------------
def mountain_torque():
    ps = xr.open_dataset(PRES_FILE)["pres"]
    hs = xr.open_dataset(HGT_FILE)["hgt"]
    if "time" in hs.dims:
        hs = hs.isel(time=0)
    h  = hs.astype("float64").values                 # gpm ~ metres

    lat_deg = ps["lat"].values; lon_deg = ps["lon"].values
    lat = lat_deg * DEG; lon = lon_deg * DEG
    nlat, nlon = lat.size, lon.size

    # dh/dlambda along each latitude circle (periodic)
    dh = np.zeros_like(h)
    for j in range(nlat):
        dh[j, :] = np.gradient(h[j, :], lon, edge_order=2)
    seam = (lon[1]-lon[0]) + (2*np.pi - (lon[-1]-lon[0]))
    dh[:, 0]  = (h[:, 1] - h[:, -1]) / seam
    dh[:, -1] = (h[:, 0] - h[:, -2]) / seam

    cosphi = np.cos(lat)[:, None]
    dphi   = np.abs(np.gradient(lat))[:, None]
    dlam   = np.abs(np.gradient(lon))[None, :]
    cell   = -A*A * dh * cosphi * dphi * dlam         # everything but p_s and time

    psv  = ps.values
    mask = region_mask(lat_deg, lon_deg, REGION)
    Tg = np.empty(psv.shape[0]); Tr = np.empty(psv.shape[0])
    for t in range(psv.shape[0]):
        field = psv[t] * cell
        Tg[t] = np.nansum(field)
        Tr[t] = np.nansum(field[mask]) if mask is not None else np.nan
    return ps["time"].values, Tg/HADLEY, Tr/HADLEY

# ----------------------------------------------------------------------
# FRICTION TORQUE   T_F = sign * a^3 * int int tau_lambda cos^2(phi) dlambda dphi
# ----------------------------------------------------------------------
def friction_torque():
    tau = xr.open_dataset(UFLX_FILE)["uflx"]
    lat_deg = tau["lat"].values; lon_deg = tau["lon"].values
    lat = lat_deg * DEG; lon = lon_deg * DEG

    cos2 = (np.cos(lat)**2)[:, None]
    dphi = np.abs(np.gradient(lat))[:, None]
    dlam = np.abs(np.gradient(lon))[None, :]
    cell = FRICTION_SIGN * A*A*A * cos2 * dphi * dlam

    tv   = tau.values
    mask = region_mask(lat_deg, lon_deg, REGION)
    Tg = np.empty(tv.shape[0]); Tr = np.empty(tv.shape[0])
    for t in range(tv.shape[0]):
        field = tv[t] * cell
        Tg[t] = np.nansum(field)
        Tr[t] = np.nansum(field[mask]) if mask is not None else np.nan
    return tau["time"].values, Tg/HADLEY, Tr/HADLEY

# ----------------------------------------------------------------------
# run & save
# ----------------------------------------------------------------------
if __name__ == "__main__":
    tmT, TMg, TMr = mountain_torque()
    tfT, TFg, TFr = friction_torque()

    sm  = pd.Series(TMg, index=pd.to_datetime(tmT), name="T_mountain_global")
    smr = pd.Series(TMr, index=pd.to_datetime(tmT), name="T_mountain_region")
    sf  = pd.Series(TFg, index=pd.to_datetime(tfT), name="T_friction_global")
    sfr = pd.Series(TFr, index=pd.to_datetime(tfT), name="T_friction_region")

    df = pd.concat([sm, smr, sf, sfr], axis=1)
    df.index.name = "month"
    df["T_total_global"] = df["T_mountain_global"] + df["T_friction_global"]
    df.to_csv("ncep_torques_monthly.csv")
    print("Saved ncep_torques_monthly.csv   (units: Hadley = 1e18 kg m^2 s^-2)")
    print("Region for *_region columns:", REGION)
    print("\nMeans (Hadley):")
    print(df.mean().round(3).to_string())
    print("\nSanity check: tropical friction torque should be NEGATIVE")
    print("(easterly trades remove westerly AAM from the atmosphere).")
